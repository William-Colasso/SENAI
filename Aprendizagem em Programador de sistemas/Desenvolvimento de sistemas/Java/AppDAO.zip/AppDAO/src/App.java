import view.UserView;

public class App {
    public static void main(String[] args) throws Exception {
        UserView view = new UserView();

        view.setVisible(true);
    }
}
